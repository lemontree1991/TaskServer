# -*- coding: utf-8 -*-
import logging
import os
import sys
import time

from modellibrary.src.main.python.core.tools.singleton import Singleton


class Logger(metaclass=Singleton):
    def __init__(self, name=None):
        """
        指定保存日志的文件路径，日志级别，以及调用文件
        将日志存入到指定的文件中
        :param name:  定义对应的程序模块名name，默认为root
        """
        # 创建一个logger
        self.__logger = logging.getLogger(name)
        self.__logger.setLevel(logging.ERROR)

        # 创建一个handler，用于写入日志文件
        rq = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
        log_name = os.path.join("logs", f"{rq}.log")

        #  这里进行判断，如果logger.handlers列表为空，则添加，否则，直接去写日志，解决重复打印的问题
        if not self.__logger.handlers:
            # 创建一个handler，用于输出到控制台
            ch = logging.StreamHandler(sys.stdout)
            # fh = logging.FileHandler(log_name)
            ch.setLevel(logging.INFO)
            # fh.setLevel(logging.ERROR)

            # 定义handler的输出格式
            fmt = "%(asctime)s - %(levelname)s - %(filename)s[line:%(lineno)d] - %(name)s - %(message)s"
            formatter = logging.Formatter(fmt)
            ch.setFormatter(formatter)
            # fh.setFormatter(formatter)

            # 给logger添加handler
            # self.__logger.addHandler(fh)
            self.__logger.addHandler(ch)

    @property
    def logger(self):
        return self.__logger


if __name__ == '__main__':
    log = Logger()
    log.logger.debug("debug")
    log.logger.info("info")
    log.logger.error("error")
    log.logger.warning("warning")
    log.logger.critical("critical")
