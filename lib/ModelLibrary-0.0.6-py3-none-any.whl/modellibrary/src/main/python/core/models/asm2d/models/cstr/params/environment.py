# -*- coding: utf-8 -*-
from ..constants import EnvironmentTypeName, EnvironmentDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class EnvironParams:
    """环境参数（目前仅有水温）"""

    def __init__(self):
        self.temp = Variable(name=EnvironmentTypeName.TEMP, default=EnvironmentDefaultValue.TEMP)
        self.temp_ref = Variable(name=EnvironmentTypeName.TEMP_REF, default=EnvironmentDefaultValue.TEMP_REF)

    def update_by_t(self, t: float):
        self.temp.update_value_by_t(t)
        self.temp_ref.update_value_by_t(t)
