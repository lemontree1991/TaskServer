# -*- coding: utf-8 -*-
from ..constants import AeratorTypeName, AeratorDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class AeratorParams:
    """曝气参数"""

    def __init__(self):
        self.ea = Variable(AeratorTypeName.EA, default=AeratorDefaultValue.EA)
        self.alpha_fine = Variable(AeratorTypeName.ALPHA_FINE, default=AeratorDefaultValue.ALPHA_FINE)
        self.beta = Variable(AeratorTypeName.BETA, default=AeratorDefaultValue.BETA)
        self.sosatu20 = Variable(AeratorTypeName.SOSATU20, default=AeratorDefaultValue.SOSATU20)
        self.sote = Variable(AeratorTypeName.SOTE, default=AeratorDefaultValue.SOTE)
        self.aerator_depth = Variable(AeratorTypeName.AERATOR_DEPTH, default=AeratorDefaultValue.AERATOR_DEPTH)

    def update_by_t(self, t: float):
        self.ea.update_value_by_t(t)
        self.alpha_fine.update_value_by_t(t)
        self.sosatu20.update_value_by_t(t)
        self.sote.update_value_by_t(t)
        self.aerator_depth.update_value_by_t(t)
