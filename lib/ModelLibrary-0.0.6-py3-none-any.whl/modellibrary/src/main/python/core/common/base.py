# -*- coding: utf-8 -*-
from abc import ABCMeta, abstractmethod


class BaseAttrs:
    """基础属性类"""

    def __init__(self, id, category):
        self.id = id  # 唯一ID
        self.category = category  # 类型


class BaseModule(metaclass=ABCMeta):
    """模型抽象基类"""
