import math

import numpy as np

from modellibrary.src.main.python.core.common.base import BaseModule, BaseAttrs
from modellibrary.src.main.python.core.models.asm2d.params.constants import ModuleType, VariableTypeName
from modellibrary.src.main.python.core.tools.logger import Logger
from .constants import PumpOperationMode, COMPONENT_NUM
from .paramset import ParamSet
from .variableset import VariableSet
from .portset import PortSet

log = Logger(__name__)


class SeclarModule(BaseModule):
    """二沉池模块"""

    def __init__(self, id: str):
        """
        沉淀池模块构造函数
        :param id:进水模块唯一编号，字符串类型
        """
        # 基础属性
        self.__attrs = BaseAttrs(id, ModuleType.SECLAR_MODULE)
        # 参数集合
        self.params = ParamSet()
        # 变量集合
        self.variables = VariableSet(self)
        # 端口集合
        self.ports = PortSet(self)

    @property
    def id(self):
        return self.__attrs.id

    @property
    def category(self):
        return self.__attrs.category

    @property
    def var_num(self):
        return COMPONENT_NUM + len(self.variables.tss_list)

    @property
    def denseness(self):
        return self.variables.denseness

    @property
    def denseness_in(self):
        return self.variables.denseness_in

    def set_params(self, data: dict):
        """设置参数
        {
            'inflow': {
                'flow': {
                    'value': 1000,
                    'is_save': False
                }
            },
        }
        """
        for p_name, vars_data in data.items():  # 解析每一类参数
            param_obj = getattr(self.params, p_name)
            for v_name, var_data in vars_data.items():  # 解析每一个参数
                var_obj = getattr(param_obj, v_name)
                for attr_name, value in var_data.items():  # 设置每一个属性
                    setattr(var_obj, attr_name, value)

    def valid(self):
        """校验"""
        if self.ports.ras_port.next:
            if self.params.operation.ras_mode == PumpOperationMode.BY_RATIO and self.params.operation.ras_ratio.value <= 0:
                return False
            if self.params.operation.ras_mode == PumpOperationMode.BY_FLOW and self.params.operation.q_ras.value <= 0:
                return False
        else:
            self.params.operation.ras_ratio.value = 0
            self.params.operation.ras_ratio.is_sequence = False
            self.params.operation.q_ras.value = 0
            self.params.operation.q_ras.is_sequence = False

        if self.ports.was_port.next:
            if self.params.operation.was_mode == PumpOperationMode.BY_RATIO and self.params.operation.was_ratio.value <= 0:
                return False
            if self.params.operation.was_mode == PumpOperationMode.BY_FLOW and self.params.operation.q_was.value <= 0:
                return False
        else:
            self.params.operation.was_ratio.value = 0
            self.params.operation.was_ratio.is_sequence = False
            self.params.operation.q_was.value = 0
            self.params.operation.q_was.is_sequence = False

        return True

    def update_denseness(self, y):
        """更新组分变量变量值，并向有下一个端口的进行变量传递"""
        # 更新溶解性组分变量
        so, sf, sa, snh, sno, spo, si, salk, snn, *tss_data = y
        self.variables.so.value = so
        self.variables.sf.value = sf
        self.variables.sa.value = sa
        self.variables.snh.value = snh
        self.variables.sno.value = sno
        self.variables.spo.value = spo
        self.variables.si.value = si
        self.variables.salk.value = salk
        self.variables.snn.value = snn
        # 更新颗粒组分变量
        for tss, value in zip(self.variables.tss_list, tss_data):
            tss.value = value

        y_x_in = self.variables.denseness_in[-10:]
        self.tss_to_x(y_x_in, tss_data)

    def push_to_next(self):
        # 推送数据
        if self.ports.out_port.next:
            # log.logger.debug(f"{self.ports.out_port.id}向{self.ports.out_port.next.id}推送数据")
            self.ports.out_port.next.transfer_data(self.ports.out_port)

        if self.ports.ras_port.next:
            # log.logger.debug(f"{self.ports.ras_port.id}向{self.ports.ras_port.next.id}推送数据")
            data = {v.name: 0 if v.name == VariableTypeName.SO else v.value for v in self.ports.ras_port.variables}
            self.ports.ras_port.next.transfer_by_data(data)

        if self.ports.was_port.next:
            # log.logger.debug(f"{self.ports.was_port.id}向{self.ports.was_port.next.id}推送数据")
            data = {v.name: 0 if v.name == VariableTypeName.SO else v.value for v in self.ports.was_port.variables}
            self.ports.was_port.next.transfer_by_data(data)

    def update_flow(self, process):
        inf_module = process.get_inf_module()
        qinf = inf_module.variables.flow_out.value

        q_remixed = self.variables.flow_in.value
        y_remixed = np.array(self.denseness_in)

        # 回流流量
        # 回流量最大不得超过沉淀池进水流量
        ras_mode = self.params.operation.ras_mode.value
        if ras_mode == PumpOperationMode.BY_RATIO:
            ras_ratio = self.params.operation.ras_ratio.value
            q_ras = min(q_remixed, ras_ratio * qinf)
        else:
            q_ras = min(q_remixed, self.params.operation.q_ras.value)
        # 回流流量变量值更新
        self.variables.flow_ras.value = q_ras
        # 排泥流量
        # 排泥流量最大不得超过沉淀池进水流量和回流量之差
        was_mode = self.params.operation.was_mode.value
        if was_mode == PumpOperationMode.BY_RATIO:
            was_ratio = self.params.operation.was_ratio.value
            q_was = min(q_remixed - q_ras, was_ratio * qinf)
        else:
            q_was = min(q_remixed - q_ras, self.params.operation.q_was.value)
        # 排泥流量变量值更新
        self.variables.flow_was.value = q_was

        # 出水流量
        q_out = q_remixed - q_ras - q_was
        self.variables.flow_out.value = q_out
        # 推送数据
        if self.ports.out_port.next:
            # log.logger.debug(f"{self.ports.out_port.id}向{self.ports.out_port.next.id}推送数据")
            self.ports.out_port.next.module.variables.flow_in.value = self.variables.flow_out.value

        if self.ports.ras_port.next:
            module = self.ports.ras_port.next.module
            module.variables.flow_converge.value = self.variables.flow_ras.value
            # log.logger.debug(f"{self.ports.ras_port.id}向{self.ports.ras_port.next.id}推送数据")

        return q_remixed, y_remixed

    #  底层、顶层颗粒性组分计算，便于输出回流、出水、排泥
    def tss_to_x(self, y_x_in, tss_data):
        icv = self.params.stoichi.icv.value
        cod_tss = np.array([1 / icv, 1 / icv, 1 / icv, 1 / icv, 3., 1 / icv, 1 / icv, 1., 1., 1.])

        tss_top = tss_data[0]
        tss_bottom = tss_data[-1]
        ratio_x = (y_x_in / (np.dot(cod_tss, y_x_in)))  # 颗粒性系数
        x_bottom = tss_bottom * ratio_x
        x_top = tss_top * ratio_x

        self.variables.xi_out.value, \
        self.variables.xs_out.value, \
        self.variables.xh_out.value, \
        self.variables.xpao_out.value, \
        self.variables.xpp_out.value, \
        self.variables.xpha_out.value, \
        self.variables.xaut_out.value, \
        self.variables.xmeoh_out.value, \
        self.variables.xmep_out.value, \
        self.variables.xii_out.value = x_top

        self.variables.xi_ras.value, \
        self.variables.xs_ras.value, \
        self.variables.xh_ras.value, \
        self.variables.xpao_ras.value, \
        self.variables.xpp_ras.value, \
        self.variables.xpha_ras.value, \
        self.variables.xaut_ras.value, \
        self.variables.xmeoh_ras.value, \
        self.variables.xmep_ras.value, \
        self.variables.xii_ras.value = x_bottom

        self.variables.xi_was.value, \
        self.variables.xs_was.value, \
        self.variables.xh_was.value, \
        self.variables.xpao_was.value, \
        self.variables.xpp_was.value, \
        self.variables.xpha_was.value, \
        self.variables.xaut_was.value, \
        self.variables.xmeoh_was.value, \
        self.variables.xmep_was.value, \
        self.variables.xii_was.value = x_bottom

    def add_to_result(self, index, y):
        so, sf, sa, snh, sno, spo, si, salk, snn, *tss_data = y

        self.variables.flow_in.append_result(index, self.variables.flow_in.value)
        self.variables.flow_out.append_result(index, self.variables.flow_out.value)
        self.variables.flow_ras.append_result(index, self.variables.flow_ras.value)
        self.variables.flow_was.append_result(index, self.variables.flow_was.value)

        self.variables.so.append_result(index, so)
        self.variables.sf.append_result(index, sf)
        self.variables.sa.append_result(index, sa)
        self.variables.snh.append_result(index, snh)
        self.variables.sno.append_result(index, sno)
        self.variables.spo.append_result(index, spo)
        self.variables.si.append_result(index, si)
        self.variables.salk.append_result(index, salk)
        self.variables.snn.append_result(index, snn)

        for tss_index, tss in enumerate(self.variables.tss_list):
            tss.append_result(index, tss_data[tss_index])

        self.variables.xi_out.append_result(index, self.variables.xi_out.value)
        self.variables.xs_out.append_result(index, self.variables.xs_out.value)
        self.variables.xh_out.append_result(index, self.variables.xh_out.value)
        self.variables.xpao_out.append_result(index, self.variables.xpao_out.value)
        self.variables.xpp_out.append_result(index, self.variables.xpp_out.value)
        self.variables.xpha_out.append_result(index, self.variables.xpha_out.value)
        self.variables.xaut_out.append_result(index, self.variables.xaut_out.value)
        self.variables.xmeoh_out.append_result(index, self.variables.xmeoh_out.value)
        self.variables.xmep_out.append_result(index, self.variables.xmep_out.value)
        self.variables.xii_out.append_result(index, self.variables.xii_out.value)

        self.variables.xi_ras.append_result(index, self.variables.xi_ras.value)
        self.variables.xs_ras.append_result(index, self.variables.xs_ras.value)
        self.variables.xh_ras.append_result(index, self.variables.xh_ras.value)
        self.variables.xpao_ras.append_result(index, self.variables.xpao_ras.value)
        self.variables.xpp_ras.append_result(index, self.variables.xpp_ras.value)
        self.variables.xpha_ras.append_result(index, self.variables.xpha_ras.value)
        self.variables.xaut_ras.append_result(index, self.variables.xaut_ras.value)
        self.variables.xmeoh_ras.append_result(index, self.variables.xmeoh_ras.value)
        self.variables.xmep_ras.append_result(index, self.variables.xmep_ras.value)
        self.variables.xii_ras.append_result(index, self.variables.xii_ras.value)

        self.variables.xi_was.append_result(index, self.variables.xi_was.value)
        self.variables.xs_was.append_result(index, self.variables.xs_was.value)
        self.variables.xh_was.append_result(index, self.variables.xh_was.value)
        self.variables.xpao_was.append_result(index, self.variables.xpao_was.value)
        self.variables.xpp_was.append_result(index, self.variables.xpp_was.value)
        self.variables.xpha_was.append_result(index, self.variables.xpha_was.value)
        self.variables.xaut_was.append_result(index, self.variables.xaut_was.value)
        self.variables.xmeoh_was.append_result(index, self.variables.xmeoh_was.value)
        self.variables.xmep_was.append_result(index, self.variables.xmep_was.value)
        self.variables.xii_was.append_result(index, self.variables.xii_was.value)

    def init(self, times, process):
        inf_module = process.get_inf_module()
        qinf = inf_module.variables.flow_out.value
        # 根据层数的参数动态创建层数变量
        self.variables.init_tss()

        # 初始化变量结果
        # 流量
        # 回流流量
        # 回流量最大不得超过沉淀池进水流量
        ras_mode = self.params.operation.ras_mode.value
        if ras_mode == PumpOperationMode.BY_RATIO:
            ras_ratio = self.params.operation.ras_ratio.value
            q_ras = ras_ratio * qinf
        else:
            q_ras = self.params.operation.q_ras.value
        self.variables.flow_ras.value = q_ras
        # 排泥流量
        # 排泥流量最大不得超过沉淀池进水流量和回流量之差
        was_mode = self.params.operation.was_mode.value
        if was_mode == PumpOperationMode.BY_RATIO:
            was_ratio = self.params.operation.was_ratio.value
            q_was = was_ratio * qinf
        else:
            q_was = self.params.operation.q_was.value
        self.variables.flow_was.value = q_was

        self.variables.flow_in.init_result(times)
        self.variables.flow_out.init_result(times)
        self.variables.flow_ras.init_result(times)
        self.variables.flow_was.init_result(times)

        # 初始条件赋值、结果初始化
        # 溶解性组分赋值
        self.variables.so.value = self.params.initial.so.value
        self.variables.sf.value = self.params.initial.sf.value
        self.variables.sa.value = self.params.initial.sa.value
        self.variables.snh.value = self.params.initial.snh.value
        self.variables.sno.value = self.params.initial.sno.value
        self.variables.spo.value = self.params.initial.spo.value
        self.variables.si.value = self.params.initial.si.value
        self.variables.salk.value = self.params.initial.salk.value
        self.variables.snn.value = self.params.initial.snn.value
        # 溶解性组分结果初始化
        self.variables.so.init_result(times)
        self.variables.sf.init_result(times)
        self.variables.sa.init_result(times)
        self.variables.snh.init_result(times)
        self.variables.sno.init_result(times)
        self.variables.spo.init_result(times)
        self.variables.si.init_result(times)
        self.variables.salk.init_result(times)
        self.variables.snn.init_result(times)
        # 颗粒组分
        for index, tss in enumerate(self.variables.tss_list):
            tss.init_result(times)  # 颗粒组分初始化结果
            tss.value = self.params.initial.tss_list[index].value

        y_x_in = self.variables.denseness_in[-10:]
        tss_data = [tss.value for tss in self.variables.tss_list]
        self.tss_to_x(y_x_in, tss_data)
        # 出水
        self.variables.xi_out.init_result(times)
        self.variables.xs_out.init_result(times)
        self.variables.xh_out.init_result(times)
        self.variables.xpao_out.init_result(times)
        self.variables.xpp_out.init_result(times)
        self.variables.xpha_out.init_result(times)
        self.variables.xaut_out.init_result(times)
        self.variables.xmep_out.init_result(times)
        self.variables.xmeoh_out.init_result(times)
        self.variables.xii_out.init_result(times)
        # 回流
        self.variables.xi_ras.init_result(times)
        self.variables.xs_ras.init_result(times)
        self.variables.xh_ras.init_result(times)
        self.variables.xpao_ras.init_result(times)
        self.variables.xpp_ras.init_result(times)
        self.variables.xpha_ras.init_result(times)
        self.variables.xaut_ras.init_result(times)
        self.variables.xmep_ras.init_result(times)
        self.variables.xmeoh_ras.init_result(times)
        self.variables.xii_ras.init_result(times)

        # 排泥
        self.variables.xi_was.init_result(times)
        self.variables.xs_was.init_result(times)
        self.variables.xh_was.init_result(times)
        self.variables.xpao_was.init_result(times)
        self.variables.xpp_was.init_result(times)
        self.variables.xpha_was.init_result(times)
        self.variables.xaut_was.init_result(times)
        self.variables.xmep_was.init_result(times)
        self.variables.xmeoh_was.init_result(times)
        self.variables.xii_was.init_result(times)
        # 进水
        self.variables.so_in.init_result(times)
        self.variables.sf_in.init_result(times)
        self.variables.sa_in.init_result(times)
        self.variables.snh_in.init_result(times)
        self.variables.sno_in.init_result(times)
        self.variables.spo_in.init_result(times)
        self.variables.si_in.init_result(times)
        self.variables.salk_in.init_result(times)
        self.variables.snn_in.init_result(times)
        self.variables.xi_in.init_result(times)
        self.variables.xs_in.init_result(times)
        self.variables.xh_in.init_result(times)
        self.variables.xpao_in.init_result(times)
        self.variables.xpp_in.init_result(times)
        self.variables.xpha_in.init_result(times)
        self.variables.xaut_in.init_result(times)
        self.variables.xmep_in.init_result(times)
        self.variables.xmeoh_in.init_result(times)
        self.variables.xii_in.init_result(times)

    def get_port_by_id(self, pid):
        """通过port id 获取port"""
        return self.ports.set.get(pid)

    def save_result(self):
        result = {}
        for var_name, var_object in self.variables.set.items():
            # FIXME 后面要改成根据is_save保存
            # if var_object.is_save:
            #     result[var_name] = var_object.results.tolist()
            result[var_name] = list(var_object.results)
        return result

    def get_current_result(self):
        """根据变量is_save属性获取当前结果"""
        result = {}
        for var_name, var_object in self.variables.set.items():
            # FIXME 后面要改成根据is_save保存
            # if var_object.is_save:
            #     result[var_name] = var_object.value
            result[var_name] = var_object.value
        return result

    def set_save_var(self, names: list):
        """设置需要保存结果的变量"""
        for name in names:
            var_object = self.variables.set.get(name)
            if var_object:
                var_object.is_save = True

    def set_init_params(self, y):
        so, sf, sa, snh, sno, spo, si, salk, snn, *tss_data = y
        self.params.initial.so.value = so
        self.params.initial.sf.value = sf
        self.params.initial.sa.value = sa
        self.params.initial.snh.value = snh
        self.params.initial.sno.value = sno
        self.params.initial.spo.value = spo
        self.params.initial.si.value = si
        self.params.initial.salk.value = salk
        self.params.initial.snn.value = snn

        for index, value in enumerate(tss_data):
            tss_object = self.params.initial.tss_list[index]
            tss_object.value = value

    def update_param_by_t(self, t: float):
        """根据时间t更新为时间序列的参数的参数值"""
        self.params.update_by_t(t)

    def ode_fun(self, qin, yin, y, process):
        """
        AMS2D模型方程定义
        :param qin: 进入二沉池的进水流量
        :param yin: 进入二沉池的进水组分浓度
        :param y: 二沉池内的待求变量，ASM2d溶解性组分+每层层悬浮固体
        :param process: 流程对象
        :return:
        """
        # NumCSTR = 3  # CSTR个数
        NumVarASM2d = 19
        NumVarASM2dS = 9
        # NumVarASM2dX = 10
        # NumCSTRVar = NumCSTR * NumVarASM2d  # 生化池当中所有的ASM2d模型组分个数

        y[y < 0.0] = 0.0  # 求解过程中将小于零的结果强制归零，否则会引起结果异常
        # *************二沉池的物理参数，表面积，水深，分层数，进料层*******
        Aset = self.params.physical.area.value
        H = self.params.physical.depth.value
        Total_Layer = self.params.physical.total_layer.value
        feedLayer = self.params.physical.feed_layer.value

        # *************二沉池待求变量的总数，溶解性组分+10层悬浮固体***********
        NumVarSeClar = NumVarASM2dS + Total_Layer  # NumVarSeClar也可以直接用len(y)定义

        s_in = yin[0: NumVarASM2dS]  # 进入二沉池的溶解性组分
        x_in = yin[NumVarASM2dS: NumVarASM2d]  # 进入二沉池的颗粒性组分

        # 化学计量学系数
        icv = self.params.stoichi.icv.value

        COD_TSS = np.array([1 / icv, 1 / icv, 1 / icv, 1 / icv, 3., 1 / icv, 1 / icv, 1., 1., 1.])
        TSSin = np.dot(COD_TSS, x_in)  # TSSin: 进入二沉池的总悬浮固体

        #  **************通过底层，顶层TSS计算出水、回流、排泥组分*************************
        ratio_x = x_in / TSSin  # 二沉池进水中，各种颗粒组分占总悬浮固体的比重
        TSSBottom = y[-1]  # 二沉池底层TSS
        XBottom = TSSBottom * ratio_x  # 二沉池底层各项颗粒组分（共10种）

        TSStop = y[NumVarSeClar - Total_Layer]  # 二沉池顶层TSS  Total_Layer = 10, 和底层相差Total_Layer（即层数）
        Xtop = TSStop * ratio_x  # 二沉池顶层各项颗粒组分（共10种） 对应二沉池的出水

        y_ras, y_was, y_eff = [np.zeros((NumVarASM2d)) for i in ["y_ras", "y_was", "y_eff"]]
        # 获得二沉池的回流浓度
        y_ras[0: NumVarASM2dS] = y[0:NumVarASM2dS]  # 二沉池回流的ASM2d溶解性组分
        y_ras[NumVarASM2dS: NumVarASM2d] = XBottom  # 二沉池回流的ASM2d颗粒性组分
        y_ras[0] = 0.  # 回流中的溶解氧强制归零
        so_ras, sf_ras, sa_ras, snh_ras, sno_ras, spo_ras, si_ras, salk_ras, snn_ras, \
        xi_ras, xs_ras, xh_ras, xpao_ras, xpp_ras, xpha_ras, xaut_ras, xmeoh_ras, xmeop_ras, xii_ras = y_ras  # 二沉池回流的ASM2d组分浓度

        # 以上，带_ras的组分均为回流中的模型组分浓度，其中s为首字母的溶解性组分，可通过微分方程直接求出，即数组y的前9个值；
        # x为首字母的颗粒性组分，无法通过微分方程直接求出，要在底层TSS（通过微分方程求出，即数组y的最后一个值）基础上进一步计算得出，
        # 可以在仿真过程中实时输出

        # 获得二沉池的剩余污泥排放浓度
        y_was[0: NumVarASM2dS] = y[0:NumVarASM2dS]  # 二沉池排泥的ASM2d溶解性组分
        y_was[NumVarASM2dS: NumVarASM2d] = XBottom  # 二沉池排泥的ASM2d颗粒性组分
        y_was[0] = 0.  # 排泥中的溶解氧强制归零
        so_was, sf_was, sa_was, snh_was, sno_was, spo_was, si_was, salk_was, snn_was, \
        xi_was, xs_was, xh_was, xpao_was, xpp_was, xpha_was, xaut_was, xmeoh_was, xmeop_was, xii_was = y_was  # 二沉池排泥的ASM2d组分浓度

        # 以上，带_was的组分均为剩余污泥中的模型组分浓度，数值上和回流中的组分等同

        # 获得二沉池顶层出水浓度
        y_eff[0: NumVarASM2dS] = y[0:NumVarASM2dS]  # 二沉池顶层出水的ASM2d溶解性组分
        y_eff[NumVarASM2dS: NumVarASM2d] = Xtop  # 二沉池顶层出水的ASM2d颗粒性组分
        so_eff, sf_eff, sa_eff, snh_eff, sno_eff, spo_eff, si_eff, salk_eff, snn_eff, \
        xi_eff, xs_eff, xh_eff, xpao_eff, xpp_eff, xpha_eff, xaut_eff, xmeoh_eff, xmeop_eff, xii_eff = y_eff  # 二沉池顶层出水的ASM2d组分浓度

        # 以上，带_eff的组分均为二沉池出水中的模型组分浓度，其中s为首字母的溶解性组分，可通过微分方程直接求出，即数组y的前9个值；
        # x为首字母的颗粒性组分，无法通过微分方程直接求出;
        # 需要在顶层TSS（通过微分方程求出，即数组y倒数第10个值--如果沉淀池按默认分成10层的话）基础上进一步计算得出;
        # 需要在仿真过程中,作为二沉池出水的模型组分实时输出
        # 进一步计算出水复合指标

        # *************定义二沉池的一维沉降过程****************************

        # ********************确定按何种回流\排泥方式********************************
        # qinf = self.params.inflow.flow_out.value  # 进入工艺流程的进水量,请勿和进入该沉淀池的进水量qin混为一谈!!
        # rasMode = self.params.SettlerOperation.ras_Mode.value
        # wasMode = self.params.SettlerOperation.was_Mode.value
        # qras = self.params.SettlerOperation.q_ras.value
        # qwas = self.params.SettlerOperation.q_was.value
        # ras_ratio = self.params.SettlerOperation.ras_ratio.value
        # was_ratio = self.params.SettlerOperation.was_ratio.value
        #
        # if rasMode == "byRatio":  # 按比例
        #     Qr = min(qin, qinf * ras_ratio)  # 回流量, 最大不得超过沉淀池进水流量
        # else:  # 按流量
        #     Qr = min(qin, qras)  # 回流量, 最大不得超过沉淀池进水流量
        #
        # if wasMode == "byRatio":  # 按比例
        #     Qw = min(qin - Qr, qinf * was_ratio)  # 剩余污泥流量，外排;  最大不得超过沉淀池进水流量和回流量之差
        # else:  # 按流量
        #     Qw = min(qin - Qr, qwas)  # 剩余污泥流量，外排;  最大不得超过沉淀池进水流量和回流量之差

        Qr = self.variables.flow_ras.value
        Qw = self.variables.flow_was.value
        Qout = qin - Qr - Qw  # 二沉池出水流量，外排
        Qu = Qr + Qw

        VolSet = Aset * H  # 二沉池容积
        vup = Qout / Aset  # 二沉池向上流量
        vdn = Qu / Aset  # 二沉池向下流量
        z = H / Total_Layer  # 二沉池每层高度

        #  沉降动力学参数
        vbdn = self.params.takacs.v_bdn.value
        vmax = self.params.takacs.v_max.value
        rh = self.params.takacs.rh.value
        rp = self.params.takacs.rp.value
        fns = self.params.takacs.fns.value
        Xminmax = self.params.takacs.x_min_max.value
        Xt = self.params.takacs.xt.value

        vs, J, J_clar, dXq, dXr, dX = [np.zeros((Total_Layer)) for i in ["vs", "J", "J_clar", "dXq", "dXr", "dX"]]
        Jcor1, Jcor2, Jcor3, Jcor4 = [np.zeros((Total_Layer)) for i in ["Jcor1", "Jcor2", "Jcor3", "Jcor4"]]

        S = y[0: NumVarASM2dS]  # 二沉池中的溶解性组分
        X = y[NumVarASM2dS: NumVarSeClar]  # 二沉池中的10层总悬浮固体

        for Layer in range(1, Total_Layer + 1, 1):  # Layer = 1-10

            Xmin = min(TSSin * fns, Xminmax)
            vs[Layer - 1] = max(0, min(vbdn, vmax * (
                    math.exp(-rh * (X[Layer - 1] - Xmin)) - math.exp(-rp * (X[Layer - 1] - Xmin)))))
            J[Layer - 1] = vs[Layer - 1] * X[Layer - 1]
            # print(J)

        for Layer in range(1, feedLayer + 1, 1):  # 进料层以上才需要考虑J_clar

            if ((X[Layer] <= Xt) and (J[Layer] < J[Layer - 1])):
                J_clar[Layer - 1] = np.mean([J[Layer], J[Layer - 1]])
            else:
                J_clar[Layer - 1] = min(J[Layer], J[Layer - 1])

        for Layer in range(1, Total_Layer + 1, 1):  # Layer = 1-10

            if Layer < feedLayer:  # 进料层以上  Layer = 1-6
                dXq[Layer - 1] = vup * (X[Layer] - X[Layer - 1]) / z  # dXq_Layer1 = vup * ( X2 - X1)
            elif Layer == feedLayer:  # 进料层  Layer = 7
                dXq[Layer - 1] = (qin * TSSin / Aset - (vdn + vup) * X[Layer - 1]) / z
            else:  # 进料层以下, Layer = 8-10
                dXq[Layer - 1] = vdn * (X[Layer - 2] - X[Layer - 1]) / z  # dXq_Layer10 = vup * ( X9 - X10) X[8] - X[9]

            if Layer > feedLayer and Layer < Total_Layer:  # 进料层和底层之间 Layer = 8, 9
                if ((X[Layer - 1] <= Xt) and (J[Layer - 1] < J[Layer - 2])):
                    Jcor1[Layer - 1] = np.mean([J[Layer - 1], J[Layer - 2]])
                else:
                    Jcor1[Layer - 1] = min(J[Layer - 1], J[Layer - 2])

                if ((X[Layer] <= Xt) and (J[Layer - 1] > J[Layer])):
                    Jcor2[Layer - 1] = np.mean([J[Layer - 1], J[Layer]])
                else:
                    Jcor2[Layer - 1] = min(J[Layer - 1], J[Layer])

            if Layer == Total_Layer:  # 底层 Layer = 10
                if ((X[Layer - 1] <= Xt) and (J[Layer - 1] < J[Layer - 2])):
                    Jcor3[Layer - 1] = np.mean([J[Layer - 1], J[Layer - 2]])
                else:
                    Jcor3[Layer - 1] = min(J[Layer - 1], J[Layer - 2])

            if Layer == feedLayer:  # 进料层, Layer = 7
                if ((X[Layer] <= Xt) and (J[Layer - 1] > J[Layer])):
                    Jcor4[Layer - 1] = np.mean([J[Layer - 1], J[Layer]])
                else:
                    Jcor4[Layer - 1] = min(J[Layer - 1], J[Layer])

            if Layer == 1:  # 顶层 Layer = 1
                dXr[Layer - 1] = -J_clar[Layer - 1] / z
            elif Layer > 1 and Layer < feedLayer:  # 顶层和进料层之间, Layer = 2-6
                dXr[Layer - 1] = (J_clar[Layer - 2] - J_clar[Layer - 1]) / z
            elif Layer == feedLayer:  # 进料层, Layer = 7
                dXr[Layer - 1] = (J_clar[Layer - 2] - Jcor4[Layer - 1]) / z
            elif Layer > feedLayer and Layer < Total_Layer:  # 进料层和底层之间 Layer = 8-9
                dXr[Layer - 1] = (Jcor1[Layer - 1] - Jcor2[Layer - 1]) / z
            else:  # 底层 Layer = 10
                dXr[Layer - 1] = Jcor3[Layer - 1] / z  # dX10 = min(J9, J10)  dx[9] = min(J[8], J[9])

        dX = dXq + dXr

        dS = (qin * s_in - Qu * S - Qout * S) / VolSet  # 溶解性组分的变化率

        dy = np.zeros(NumVarSeClar)
        dy[0: NumVarASM2dS] = dS
        dy[NumVarASM2dS: NumVarSeClar] = dX

        return dy  # , Qr, Qw, y_ras, y_was
