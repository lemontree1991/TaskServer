# -*- coding: utf-8 -*-
from functools import reduce

import numpy as np


class PublicFun:
    """公共函数"""

    def __init__(self):
        pass

    @staticmethod
    def asm2d_get_compos(y_asm2d, stoichi_params_obj):
        # ***************把ASM2d模型组分，组合成复合指标******
        so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii = y_asm2d

        # 化学计量学系数
        icv = stoichi_params_obj.icv.value
        fbod = stoichi_params_obj.ivt.value

        insi = stoichi_params_obj.insi.value
        insf = stoichi_params_obj.insf.value
        inxi = stoichi_params_obj.inxi.value
        inxs = stoichi_params_obj.inxs.value
        inbm = stoichi_params_obj.inbm.value

        ipsi = stoichi_params_obj.ipsi.value
        ipsf = stoichi_params_obj.ipsf.value
        ipxi = stoichi_params_obj.ipxi.value
        ipxs = stoichi_params_obj.ipxs.value
        ipbm = stoichi_params_obj.ipbm.value

        cod = sf + sa + si + xi + xs + xh + xpao + xpha + xaut
        bod = fbod * (sf + sa + xs + xh + xpao + xpha + xaut)
        xbod = fbod * (xs + xh + xpao + xpha + xaut)
        sbod = fbod * (sf + sa)
        xbodu = xs + xh + xpao + xpha + xaut
        sbodu = sf + sa
        xcod = xbodu + xi
        scod = sbodu + si

        tss = (xi + xs + xh + xpao + xpha + xaut) / icv + 3.0 * xpp + xmeoh + xmep + xii
        mlvss = xcod / icv
        ixss = tss - mlvss

        xtkn = xi * inxi + xs * inxs + (xh + xpao + xaut) * inbm
        stkn = snh + sf * insf + si * insi
        tkn = xtkn + stkn
        tn = xtkn + stkn + sno

        xtp = 0.205 * xmep + xpp + xi * ipxi + xs * ipxs + (xh + xpao + xaut) * ipbm
        stp = spo + sf * ipsf + si * ipsi
        tp = xtp + stp

        # 全部复合指标
        compound = np.array([cod, bod, xbod, sbod, xcod, scod, tss, mlvss, xtkn, stkn, tkn, tn, xtp, stp, tp])

        # 选择出常用复合指标，也可沿用全部
        compound_common = np.array([cod, bod, tss, tn, tp])

        return compound_common


class WaterProcessor:
    """
    进出水处理类，用于分流、汇流
    """

    @staticmethod
    def splitter(q, ratios):
        """
        分流器
        :param q: 进水流量
        :param ratios: 分流比例集合
        :return: 分流流量集合
        """
        result = list(map(lambda x: x * q, ratios))

        if 0 < reduce(lambda x, y: x + y, ratios) < 1:  # 分流比例之和 >0 且 <1
            # 追加入水流量 - 分流流量之和
            result.append(q - reduce(lambda x, y: x + y, result))

        return result

    @staticmethod
    def combiner(qs, ys):
        """
        汇流器
        :param qs: 进水流量集合
        :param ys: 组分浓度集合
        :return: 汇流流量、汇流浓度
        """
        q_total = reduce(lambda x, y: x + y, qs)  # 进水流量求和
        y_list = list(map(lambda x, y: x * y, qs, ys))  # 每项进水*浓度的结果集合
        y = reduce(lambda x, y: x + y, y_list) / q_total
        return q_total, y
