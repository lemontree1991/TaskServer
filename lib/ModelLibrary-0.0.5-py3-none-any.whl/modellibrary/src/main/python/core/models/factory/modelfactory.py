# -*- coding: utf-8 -*-
# @Time : 2020/4/6 15:57
# @Author : daijie
# @Site : 
# @File : modelfactory.py
# @Software: PyCharm

from modellibrary.src.main.python.core.models.asm2d.models.cstr.cstr import CSTRModule
from modellibrary.src.main.python.core.models.asm2d.models.inflow.inflow import InflowModule
from modellibrary.src.main.python.core.models.asm2d.models.seclar.seclar import SeclarModule


class ModelFactory:
    Inflow = "InflowModule"
    CSTR = "CSTRModule"
    SECLAR = "SeclarModule"

    def __init__(self):
        pass

    @classmethod
    def create_model_by_name(cls, model_name, model_id):
        if model_name in globals():
            model_obj = globals()[model_name](model_id)
            return model_obj
        else:
            # 没有找到模型
            return None
