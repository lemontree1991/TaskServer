# -*- coding: utf-8 -*-
from enum import Enum


class StoichiDefaultValue:
    """化学计量系数默认值"""
    ICV = 1.48
    IVT = 0.6
    FBOD = 0.66

    INSI = 0.01
    INSF = 0.03
    INXI = 0.02
    INXS = 0.04
    INBM = 0.07
    IPSI = 0.00
    IPSF = 0.01
    IPXI = 0.01
    IPXS = 0.01
    IPBM = 0.02
    ITSSXI = 0.75
    ITSSXS = 0.75
    ITSSBM = 0.9
    FSI = 0.00
    YH = 0.625
    YAUT = 0.24
    FXI = 0.10
    YPAO = 0.625
    YPO = 0.40
    YPHA = 0.20


class ModuleType(Enum):
    """模型类别"""
    # 未知
    NONE = 0
    # 进水模块
    INFLOW_MODULE = 1
    # 完全混合反应池
    REACTION_MODULE = 2
    # 二沉池
    SECLAR_MODULE = 3


class PortType(Enum):
    """端口类别"""
    # 未知
    NONE = 0
    OUT_PORT = 1
    IN_PORT = 2
    CONVERGE_PORT = 3
    PUMP_PORT = 4
    WAS_PORT = 5
    RAS_PORT = 6


class VariableTypeName:
    """变量类别 各端口流量+组分"""
    # 流量类别
    FLOW = "flow"
    # 组分类别
    SO = "so"
    SF = "sf"
    SA = "sa"
    SNH = "snh"
    SNO = "sno"
    SPO = "spo"
    SI = "si"
    SALK = "salk"
    SNN = "snn"
    XI = "xi"
    XS = "xs"
    XH = "xh"
    XPAO = "xpao"
    XPP = "xpp"
    XPHA = "xpha"
    XAUT = "xaut"
    XMEOH = "xmeoh"
    XMEP = "xmep"
    XII = "xii"
    # 复合指标
    COD = "cod"
    BOD = "bod"
    TSS = "tss"
    TN = "tn"
    TP = "tp"


class StoichiTypeName:
    """化学计量系数类别"""
    ICV = "icv"
    IVT = "ivt"
    FBOD = "fbod"

    INSI = "insi"
    INSF = "insf"
    INXI = "inxi"
    INXS = "inxs"
    INBM = "inbm"
    IPSI = "ipsi"
    IPSF = "ipsf"
    IPXI = "ipxi"
    IPXS = "ipxs"
    IPBM = "ipbm"
    ITSSXI = "itssxi"
    ITSSXS = "itssxs"
    ITSSBM = "itssbm"
    FSI = "fsi"
    YH = "yh"
    YAUT = "yaut"
    FXI = "fxi"
    YPAO = "ypao"
    YPO = "ypo"
    YPHA = "ypha"
