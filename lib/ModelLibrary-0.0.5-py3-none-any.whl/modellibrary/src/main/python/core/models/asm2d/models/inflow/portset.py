# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import PortType
from modellibrary.src.main.python.core.common.port import Port


class PortSet:
    """模块端口集合"""

    def __init__(self, module):
        self.__module = module

        self.out_port = Port(module=module, id=f"{module.id}_{PortType.OUT_PORT.value}", category=PortType.OUT_PORT)

        self.out_port.add_vars(self.__module.variables.get_port_out_vars())

        self.set = {
            self.out_port.id: self.out_port
        }

    @property
    def module(self):
        return self.__module
