# -*- coding: utf-8 -*-
import time
import warnings

import numpy as np
from scipy.integrate import ode

from .constants import *
from .process import StatusCode
from ..models.asm2d.params.constants import ModuleType
from ..tools.logger import Logger
from ..tools.public import timer

log = Logger(__name__)
warnings.filterwarnings('error')


class Arithmetic:
    """通用工艺算法"""

    def __init__(self, process, start=0, terminal=1, interval=0.01):
        self.process = process
        self.start = start  # 仿真开始时间
        self.terminal = terminal  # 仿真结束时间
        self.interval = interval  # 仿真通讯间隔

        self.result_test = None  # 测试仿真结果
        self.result = {}

    @timer
    def solve(self, monitor_fun=None, update_progress=None, before_ode_fun=None, after_ode_fun=None):
        """
        1.初始化所有数据（初始化参数、变量、模型，构造结果的数据结构）
        2.构造方程组
        3.解方程（解方程过程中实时发送数据）
        4.填充结果的数据结构
        """
        y_0 = self.load_process()
        s = ode(self.process.build_process).set_integrator("lsoda", method="adams")  # set_integrator 设置积分器
        s.set_initial_value(y=y_0, t=self.start)  # 设置微分方程初值
        # s.set_f_params(process)  # 设置参数
        self.result_test = np.array(y_0)
        count = 0
        t = s.t
        total_count = int((self.terminal - self.start) / self.interval)
        for i in range(total_count):
            print(f"计算第{count}次")

            if monitor_fun and update_progress:
                monitor_fun(self)

                while self.process.status == StatusCode.PAUSE:
                    monitor_fun(self)
                    update_progress(
                        state=StatusCode.PROGRESS,
                        data={
                            'progress': round(count / total_count, 2),
                            'result': self.get_current_result()
                        }
                    )
                    time.sleep(1)

                update_progress(
                    state=StatusCode.PROGRESS,
                    data={
                        'progress': round(count / total_count, 2),
                        'result': self.get_current_result()
                    }
                )

            if s.successful():
                # 根据时间t更新模型参数
                for module in self.process.modules:
                    module.update_param_by_t(t)

                # 计算之前的回调函数
                if before_ode_fun is not None:
                    before_ode_fun(self.process, t, self.terminal)

                count += 1
                try:
                    s.integrate(s.t + self.interval)
                except Warning as w:
                    log.logger.error(f"{w}")
                    break
                # Fixme 这里仅做测试后期删除
                self.result_test = np.row_stack((self.result_test, s.y))
                y_index = 0
                for index, module in enumerate(self.process.modules):
                    if module.category == ModuleType.INFLOW_MODULE:
                        module.add_to_result(count, module.denseness)
                        continue
                    var_num = module.var_num
                    reaction_y = s.y[y_index: y_index + var_num]
                    module.add_to_result(count, reaction_y)
                    y_index += var_num

                # Fixme，临时调整，后期修改
                t = round(s.t, 2)

                # 计算之后的回调函数
                if after_ode_fun is not None:
                    after_ode_fun(self.process, t, self.terminal)

        if self.process.use_init_value:
            last_result = s.y
            y_index = 0
            for index, module in enumerate(self.process.modules[1:]):
                var_num = module.var_num
                reaction_y = last_result[y_index: y_index + var_num]
                module.set_init_params(reaction_y)
                y_index += var_num

    def load_process(self):
        """
        开始仿真计算前初始化模型：
            1.根据设置参数初始化模型的变量值
            2.根据仿真时长初始化变量的结果为np.array数组
        """
        y_0 = []
        calculation_times = int((self.terminal - self.start) / self.interval + 1)
        # 遍历模型 1.各个模型进行初始化 2.各个模型根据连接关系进行变量传递 3.拼接各个模型的组分初始值
        for index, module in enumerate(self.process.modules):
            module.update_param_by_t(0.)  # 更新为0时刻时序值的参数的参数值
            module.init(calculation_times, self.process)  # 每个模型进行初始化
            if index == 0:
                last_port = module.ports.out_port
                next_port = last_port.next
                next_port.transfer_data(last_port)
                continue

            if not module.valid():
                raise Exception(f'{module.id}:回流参数配置有误')

            denseness = module.denseness
            module.push_to_next()  # 向有下一个端口的进行变量传递
            y_0 = y_0 + denseness

        # 根据连接求解流量值并更新变量结果
        for index, module in enumerate(self.process.modules):
            if module.category != ModuleType.INFLOW_MODULE:
                module.update_flow(self.process)
            module.add_to_result(0, module.denseness)

        y_0 = np.array(y_0)
        return y_0

    def save_result(self):
        modules = self.process.modules
        for module in modules:
            result = module.save_result()
            self.result[module.id] = result

    def get_custom_result(self, *args, **kwargs):
        """获取所有反应池，根据需求对结果进行聚合"""
        # TODO 入库 报表

    def get_current_result(self):
        result = {}
        modules = self.process.modules
        for module in modules:
            result[module.id] = module.get_current_result()
        return result
