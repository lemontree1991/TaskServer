# -*- coding : utf-8 -*-
import json
import os
import numpy as np

from modellibrary.src.main.python.core.algorithm.process_plus import ProcessPlus
from modellibrary.tests.public.public import before_ode_fun, after_ode_fun

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # config_path = 'resources/config.json'
    config_path = 'resources/taihe_schema.json'
    with open(config_path, encoding='utf-8') as f:
        data = json.load(f)
    process_plus = ProcessPlus(os.path.join(base_dir, config_path), data=data)
    process_plus.arithmetic.solve(before_ode_fun, after_ode_fun)
    process_plus.arithmetic.save_result()  # 保存结果字典
    np.savetxt(os.path.join(base_dir, 'result.txt'), process_plus.arithmetic.result_test, fmt="%.5f", delimiter=",")
    # print(process_plus.arithmetic.result)
