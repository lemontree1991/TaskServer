# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.initialization import InitParams
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.kinetic import KineticParams
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.operation import OperationParams
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.physical import PhysicalParams
from modellibrary.src.main.python.core.models.asm2d.params.stoichi import StoichiParams
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.aerator import AeratorParams
from modellibrary.src.main.python.core.models.asm2d.models.cstr.params.environment import EnvironParams


class ParamSet:
    """参数集合"""

    def __init__(self):
        # 初始化参数
        self.initial = InitParams()
        # 物理参数
        self.physical = PhysicalParams()
        # 运行参数
        self.operation = OperationParams()
        # 动力学参数
        self.kinetic = KineticParams()
        # 化学计量学系数
        self.stoichi = StoichiParams()
        # 曝气参数
        self.aerator = AeratorParams()
        #  环境参数
        self.environment = EnvironParams()

    def update_by_t(self, t: float):
        self.initial.update_by_t(t)
        self.physical.update_by_t(t)
        self.operation.update_by_t(t)
        self.kinetic.update_by_t(t)
        self.stoichi.update_by_t(t)
        self.aerator.update_by_t(t)
        self.environment.update_by_t(t)
