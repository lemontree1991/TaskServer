# -*- coding: utf-8 -*-
from enum import Enum

COMPONENT_NUM = 19


class InitComponentDefaultValue:
    """组分初始值默认值"""
    SO = 2.
    SF = 5.
    SA = 5.
    SNH = 2.
    SNO = 20.
    SPO = 5.
    SI = 30.
    SALK = 7.
    SNN = 0.
    XI = 1000.
    XS = 100.
    XH = 500.
    XPAO = 200.
    XPP = 100.
    XPHA = 100.
    XAUT = 100.
    XMEOH = 1.
    XMEP = 1.
    XII = 1000.


class PhysicalDefaultValue:
    """物理学默认值"""
    VOLUME = 200.


class OperationDefaultValue:
    """运行参数默认值"""
    RAS_RATIO = 1.  # 回流比
    Q_PUMP = 0.
    Q_AIR = 0.


class KineticDefaultValue:
    """动力学参数默认值"""
    # 水解参数
    KH_HYDRO_TEMP_REF = 3.00
    GNO_HYDRO = 0.60
    GFE_HYDRO = 0.40
    KO_HYDRO = 0.20
    KNO_HYDRO = 0.50
    KX_HYDRO = 0.10
    # 异养菌
    UH_HERTER_TEMP_REF = 6.00
    QFE_HERTER_TEMP_REF = 3.00
    BH_HERTER_TEMP_REF = 0.40
    GNO_HERTER = 0.60
    KOH_ERTER = 0.20
    KF_HERTER = 4.00
    KFE_HERTER = 4.00
    KA_HERTER = 4.00
    KNO_HERTER = 0.50
    KNH_HERTER = 0.05
    KP_HERTER = 0.01
    KALK_HERTER = 0.10
    # 聚磷菌
    QPHA_PHOS_TEMP_REF = 3.00
    QPP_PHOS_TEMP_REF = 1.50
    UPAO_PHOS_TEMP_REF = 1.00
    BPAO_PHOS_TEMP_REF = 0.20
    BPP_PHOS_TEMP_REF = 0.20
    BPHA_PHOS_TEMP_REF = 0.20
    GNO_PHOS = 0.60
    KO_PHOS = 0.20
    KNO_PHOS = 0.50
    KA_PHOS = 4.00
    KNH_PHOS = 0.05
    KPS_PHOS = 0.20
    KPP_HOS = 0.01
    KALK_PHOS = 0.10
    KPP_PHOS = 0.01
    KMAX_PHOS = 0.34
    KIPP_PHOS = 0.02
    KPHA_PHOS = 0.01
    # 自养菌
    UAUT_TEMP_REF = 1.0
    BAUT_TEMP_REF = 0.15
    KO_AUT = 0.50
    KNH_AUT = 1.00
    KALK_AUT = 0.50
    KP_AUT = 0.01
    # 沉淀和再溶解
    KPRE = 1.00
    KRED = 0.60
    KALK_PRE = 0.50


class AeratorDefaultValue:
    """曝气参数默认值"""
    EA = 27.76533841  # 氧转移效率
    ALPHA_FINE = 0.6
    BETA = 0.95
    SOSATU20 = 9.09  # 20度清水的饱和溶解氧
    SOTE = 0.285
    AERATOR_DEPTH = 4.3  # 曝气装置埋深


class EnvironmentDefaultValue:
    """环境参数默认值"""
    TEMP = 20.
    TEMP_REF = 20.


class PhysicalTypeName:
    """物理学类别"""
    VOLUME = "volume"


class PumpOperationMode(Enum):
    """回流模式选择"""
    BY_RATIO = 1
    BY_FLOW = 2


class OperationTypeName:
    """运行参数类别"""
    RAS_MODE = "ras_mode"  # 回流模式
    RAS_RATIO = "ras_ratio"  # 回流比
    Q_PUMP = "q_pump"
    Q_AIR = "q_air"


class KineticTypeName:
    """动力学参数类别"""
    # 水解参数
    KH_HYDRO_TEMP_REF = "kh_hydro_temp_ref"
    GNO_HYDRO = "gno_hydro"
    GFE_HYDRO = "gfe_hydro"
    KO_HYDRO = "ko_hydro"
    KNO_HYDRO = "kno_hydro"
    KX_HYDRO = "kx_hydro"
    # 异养菌
    UH_HERTER_TEMP_REF = "uh_herter_temp_ref"
    QFE_HERTER_TEMP_REF = "qfe_herter_temp_ref"
    BH_HERTER_TEMP_REF = "bh_herter_temp_ref"
    GNO_HERTER = "gno_herter"
    KOH_ERTER = "ko_herter"
    KF_HERTER = "kf_herter"
    KFE_HERTER = "kfe_herter"
    KA_HERTER = "ka_herter"
    KNO_HERTER = "kno_herter"
    KNH_HERTER = "knh_herter"
    KP_HERTER = "kp_herter"
    KALK_HERTER = "kalk_herter"
    # 聚磷菌
    QPHA_PHOS_TEMP_REF = "qpha_phos_temp_ref"
    QPP_PHOS_TEMP_REF = "qpp_phos_temp_ref"
    UPAO_PHOS_TEMP_REF = "upao_phos_temp_ref"
    BPAO_PHOS_TEMP_REF = "bpao_phos_temp_ref"
    BPP_PHOS_TEMP_REF = "bpp_phos_temp_ref"
    BPHA_PHOS_TEMP_REF = "bpha_phos_temp_ref"
    GNO_PHOS = "gno_phos"
    KO_PHOS = "ko_phos"
    KNO_PHOS = "kno_phos"
    KA_PHOS = "ka_phos"
    KNH_PHOS = "knh_phos"
    KPS_PHOS = "kps_phos"
    KPP_HOS = "kp_phos"
    KALK_PHOS = "kalk_phos"
    KPP_PHOS = "kpp_phos"
    KMAX_PHOS = "kmax_phos"
    KIPP_PHOS = "kipp_phos"
    KPHA_PHOS = "kpha_phos"
    # 自养菌
    UAUT_TEMP_REF = "uaut_temp_ref"
    BAUT_TEMP_REF = "baut_temp_ref"
    KO_AUT = "ko_aut"
    KNH_AUT = "knh_aut"
    KALK_AUT = "kalk_aut"
    KP_AUT = "kp_aut"
    # 沉淀和再溶解
    KPRE = "kpre"
    KRED = "kred"
    KALK_PRE = "kalk_pre"


class AeratorTypeName:
    """曝气参数类别"""
    EA = "ea"
    ALPHA_FINE = "alpha_fine"
    BETA = "beta"
    SOSATU20 = "sosatu20"
    SOTE = "sote"
    AERATOR_DEPTH = "aerator_depth"


class EnvironmentTypeName:
    """环境参数类别"""
    TEMP = "temp"
    TEMP_REF = "temp_ref"
