# -*- coding: utf-8 -*-
from ..constants import OperationTypeName, OperationDefaultValue, PumpOperationMode
from modellibrary.src.main.python.core.common.variable import Variable


class OperationParams:
    """运行参数"""

    def __init__(self):
        self.ras_mode = Variable(name=OperationTypeName.RAS_MODE, default=PumpOperationMode.BY_RATIO)
        self.ras_ratio = Variable(name=OperationTypeName.RAS_RATIO, default=OperationDefaultValue.RAS_RATIO)
        self.q_pump = Variable(name=OperationTypeName.Q_PUMP, default=OperationDefaultValue.Q_PUMP)
        self.q_air = Variable(name=OperationTypeName.Q_AIR, default=OperationDefaultValue.Q_AIR)

    def update_by_t(self, t: float):
        self.ras_mode.update_value_by_t(t)
        self.ras_ratio.update_value_by_t(t)
        self.q_pump.update_value_by_t(t)
        self.q_air.update_value_by_t(t)
