# -*- coding: utf-8 -*-
from ..constants import KineticTypeName, KineticDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class KineticParams:
    """动力学参数"""

    def __init__(self):
        self.kh_hydro_temp_ref = Variable(KineticTypeName.KH_HYDRO_TEMP_REF,
                                          default=KineticDefaultValue.KH_HYDRO_TEMP_REF)
        self.gno_hydro = Variable(KineticTypeName.GNO_HYDRO, default=KineticDefaultValue.GNO_HYDRO)
        self.gfe_hydro = Variable(KineticTypeName.GFE_HYDRO, default=KineticDefaultValue.GFE_HYDRO)
        self.ko_hydro = Variable(KineticTypeName.KO_HYDRO, default=KineticDefaultValue.KO_HYDRO)
        self.kno_hydro = Variable(KineticTypeName.KNO_HYDRO, default=KineticDefaultValue.KNO_HYDRO)
        self.kx_hydro = Variable(KineticTypeName.KX_HYDRO, default=KineticDefaultValue.KX_HYDRO)

        self.uh_herter_temp_ref = Variable(KineticTypeName.UH_HERTER_TEMP_REF,
                                           default=KineticDefaultValue.UH_HERTER_TEMP_REF)
        self.qfe_herter_temp_ref = Variable(KineticTypeName.QFE_HERTER_TEMP_REF,
                                            default=KineticDefaultValue.QFE_HERTER_TEMP_REF)
        self.bh_herter_temp_ref = Variable(KineticTypeName.BH_HERTER_TEMP_REF,
                                           default=KineticDefaultValue.BH_HERTER_TEMP_REF)
        self.gno_herter = Variable(KineticTypeName.GNO_HERTER, default=KineticDefaultValue.GNO_HERTER)
        self.ko_herter = Variable(KineticTypeName.KOH_ERTER, default=KineticDefaultValue.KOH_ERTER)
        self.kf_herter = Variable(KineticTypeName.KF_HERTER, default=KineticDefaultValue.KF_HERTER)
        self.kfe_herter = Variable(KineticTypeName.KFE_HERTER, default=KineticDefaultValue.KFE_HERTER)
        self.ka_herter = Variable(KineticTypeName.KA_HERTER, default=KineticDefaultValue.KA_HERTER)
        self.kno_herter = Variable(KineticTypeName.KNO_HERTER, default=KineticDefaultValue.KNO_HERTER)
        self.knh_herter = Variable(KineticTypeName.KNH_HERTER, default=KineticDefaultValue.KNH_HERTER)
        self.kp_herter = Variable(KineticTypeName.KP_HERTER, default=KineticDefaultValue.KP_HERTER)
        self.kalk_herter = Variable(KineticTypeName.KALK_HERTER, default=KineticDefaultValue.KALK_HERTER)

        self.qpha_phos_temp_ref = Variable(KineticTypeName.QPHA_PHOS_TEMP_REF,
                                           default=KineticDefaultValue.QPHA_PHOS_TEMP_REF)
        self.qpp_phos_temp_ref = Variable(KineticTypeName.QPP_PHOS_TEMP_REF,
                                          default=KineticDefaultValue.QPP_PHOS_TEMP_REF)
        self.upao_phos_temp_ref = Variable(KineticTypeName.UPAO_PHOS_TEMP_REF,
                                           default=KineticDefaultValue.UPAO_PHOS_TEMP_REF)
        self.bpao_phos_temp_ref = Variable(KineticTypeName.BPAO_PHOS_TEMP_REF,
                                           default=KineticDefaultValue.BPAO_PHOS_TEMP_REF)
        self.bpp_phos_temp_ref = Variable(KineticTypeName.BPP_PHOS_TEMP_REF,
                                          default=KineticDefaultValue.BPP_PHOS_TEMP_REF)
        self.bpha_phos_temp_ref = Variable(KineticTypeName.BPHA_PHOS_TEMP_REF,
                                           default=KineticDefaultValue.BPHA_PHOS_TEMP_REF)
        self.gno_phos = Variable(KineticTypeName.GNO_PHOS, default=KineticDefaultValue.GNO_PHOS)
        self.ko_phos = Variable(KineticTypeName.KO_PHOS, default=KineticDefaultValue.KO_PHOS)
        self.kno_phos = Variable(KineticTypeName.KNO_PHOS, default=KineticDefaultValue.KNO_PHOS)
        self.ka_phos = Variable(KineticTypeName.KA_PHOS, default=KineticDefaultValue.KA_PHOS)
        self.knh_phos = Variable(KineticTypeName.KNH_PHOS, default=KineticDefaultValue.KNH_PHOS)
        self.kps_phos = Variable(KineticTypeName.KPS_PHOS, default=KineticDefaultValue.KPS_PHOS)
        self.kp_phos = Variable(KineticTypeName.KPP_HOS, default=KineticDefaultValue.KPP_HOS)
        self.kalk_phos = Variable(KineticTypeName.KALK_PHOS, default=KineticDefaultValue.KALK_PHOS)
        self.kpp_phos = Variable(KineticTypeName.KPP_PHOS, default=KineticDefaultValue.KPP_PHOS)
        self.kmax_phos = Variable(KineticTypeName.KMAX_PHOS, default=KineticDefaultValue.KMAX_PHOS)
        self.kipp_phos = Variable(KineticTypeName.KIPP_PHOS, default=KineticDefaultValue.KIPP_PHOS)
        self.kpha_phos = Variable(KineticTypeName.KPHA_PHOS, default=KineticDefaultValue.KPHA_PHOS)

        self.uAut_temp_ref = Variable(KineticTypeName.UAUT_TEMP_REF, default=KineticDefaultValue.UAUT_TEMP_REF)
        self.bAut_temp_ref = Variable(KineticTypeName.BAUT_TEMP_REF, default=KineticDefaultValue.BAUT_TEMP_REF)
        self.ko_aut = Variable(KineticTypeName.KO_AUT, default=KineticDefaultValue.KO_AUT)
        self.knh_aut = Variable(KineticTypeName.KNH_AUT, default=KineticDefaultValue.KNH_AUT)
        self.kalk_aut = Variable(KineticTypeName.KALK_AUT, default=KineticDefaultValue.KALK_AUT)
        self.kp_aut = Variable(KineticTypeName.KP_AUT, default=KineticDefaultValue.KP_AUT)

        self.kpre = Variable(KineticTypeName.KPRE, default=KineticDefaultValue.KPRE)
        self.kred = Variable(KineticTypeName.KRED, default=KineticDefaultValue.KRED)
        self.kalk_pre = Variable(KineticTypeName.KALK_PRE, default=KineticDefaultValue.KALK_PRE)

    def update_by_t(self, t: float):
        self.kh_hydro_temp_ref.update_value_by_t(t)
        self.gno_hydro.update_value_by_t(t)
        self.gfe_hydro.update_value_by_t(t)
        self.ko_hydro.update_value_by_t(t)
        self.kno_hydro.update_value_by_t(t)
        self.kx_hydro.update_value_by_t(t)

        self.uh_herter_temp_ref.update_value_by_t(t)
        self.qfe_herter_temp_ref.update_value_by_t(t)
        self.bh_herter_temp_ref.update_value_by_t(t)
        self.gno_herter.update_value_by_t(t)
        self.ko_herter.update_value_by_t(t)
        self.kf_herter.update_value_by_t(t)
        self.kfe_herter.update_value_by_t(t)
        self.ka_herter.update_value_by_t(t)
        self.kno_herter.update_value_by_t(t)
        self.knh_herter.update_value_by_t(t)
        self.kp_herter.update_value_by_t(t)
        self.kalk_herter.update_value_by_t(t)

        self.qpha_phos_temp_ref.update_value_by_t(t)
        self.qpp_phos_temp_ref.update_value_by_t(t)
        self.upao_phos_temp_ref.update_value_by_t(t)
        self.bpao_phos_temp_ref.update_value_by_t(t)
        self.bpp_phos_temp_ref.update_value_by_t(t)
        self.bpha_phos_temp_ref.update_value_by_t(t)
        self.gno_phos.update_value_by_t(t)
        self.ko_phos.update_value_by_t(t)
        self.kno_phos.update_value_by_t(t)
        self.ka_phos.update_value_by_t(t)
        self.knh_phos.update_value_by_t(t)
        self.kps_phos.update_value_by_t(t)
        self.kp_phos.update_value_by_t(t)
        self.kalk_phos.update_value_by_t(t)
        self.kpp_phos.update_value_by_t(t)
        self.kmax_phos.update_value_by_t(t)
        self.kipp_phos.update_value_by_t(t)
        self.kpha_phos.update_value_by_t(t)

        self.uAut_temp_ref.update_value_by_t(t)
        self.bAut_temp_ref.update_value_by_t(t)
        self.ko_aut.update_value_by_t(t)
        self.knh_aut.update_value_by_t(t)
        self.kalk_aut.update_value_by_t(t)
        self.kp_aut.update_value_by_t(t)

        self.kpre.update_value_by_t(t)
        self.kred.update_value_by_t(t)
        self.kalk_pre.update_value_by_t(t)
