# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.models.inflow.params.inflow import InflowParams
from modellibrary.src.main.python.core.models.asm2d.params.stoichi import StoichiParams


class ParamSet:
    """参数集合"""

    def __init__(self):
        # 进水水质参数
        self.inflow = InflowParams()
        # 化学计量系数参数
        self.stoichi = StoichiParams()

    def update_by_t(self, t: float):
        self.inflow.update_by_t(t)
        self.stoichi.update_by_t(t)
