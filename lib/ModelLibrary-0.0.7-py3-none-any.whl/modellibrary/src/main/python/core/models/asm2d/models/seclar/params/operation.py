# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.common.variable import Variable
from ..constants import OperationTypeName, OperationDefaultValue, PumpOperationMode


class OperationParams:
    """运行参数"""

    def __init__(self):
        self.ras_mode = Variable(name=OperationTypeName.RAS_MODE, default=PumpOperationMode.BY_RATIO)
        self.was_mode = Variable(name=OperationTypeName.WAS_MODE, default=PumpOperationMode.BY_RATIO)
        self.ras_ratio = Variable(name=OperationTypeName.RAS_RATIO, default=OperationDefaultValue.RAS_RATIO)
        self.was_ratio = Variable(name=OperationTypeName.WAS_RATIO, default=OperationDefaultValue.WAS_RATIO)
        self.q_ras = Variable(name=OperationTypeName.Q_RAS, default=OperationDefaultValue.Q_RAS)
        self.q_was = Variable(name=OperationTypeName.Q_WAS, default=OperationDefaultValue.Q_WAS)

    def update_by_t(self, t: float):
        self.ras_mode.update_value_by_t(t)
        self.was_mode.update_value_by_t(t)
        self.ras_ratio.update_value_by_t(t)
        self.was_ratio.update_value_by_t(t)
        self.q_ras.update_value_by_t(t)
        self.q_was.update_value_by_t(t)
