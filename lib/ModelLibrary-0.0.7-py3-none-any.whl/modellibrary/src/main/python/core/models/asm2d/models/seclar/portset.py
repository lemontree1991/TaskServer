# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import PortType
from modellibrary.src.main.python.core.common.port import Port


class PortSet:
    """模块端口集合"""

    def __init__(self, module):
        self.__module = module
        self.in_port = Port(module, f"{module.id}_{PortType.IN_PORT.value}", PortType.IN_PORT)
        self.out_port = Port(module, f"{module.id}_{PortType.OUT_PORT.value}", PortType.OUT_PORT)
        self.ras_port = Port(module, f"{module.id}_{PortType.RAS_PORT.value}", PortType.RAS_PORT)
        self.was_port = Port(module, f"{module.id}_{PortType.WAS_PORT.value}", PortType.WAS_PORT)

        self.in_port.add_vars(self.__module.variables.get_port_in_vars())
        self.out_port.add_vars(self.__module.variables.get_port_out_vars())
        self.ras_port.add_vars(self.__module.variables.get_port_ras_vars())
        self.was_port.add_vars(self.__module.variables.get_port_was_vars())

        self.set = {
            self.in_port.id: self.in_port,
            self.out_port.id: self.out_port,
            self.ras_port.id: self.ras_port,
            self.was_port.id: self.was_port,
        }

    @property
    def module(self):
        return self.__module
