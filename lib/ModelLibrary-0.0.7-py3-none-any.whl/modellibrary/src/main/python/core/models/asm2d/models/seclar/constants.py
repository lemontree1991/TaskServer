# -*- coding: utf-8 -*-
from enum import Enum

COMPONENT_NUM = 9


class InitComponentDefaultValue:
    """组分初始值默认值"""
    # 溶解性组分初值
    SO = 2.
    SF = 5.
    SA = 5.
    SNH = 2.
    SNO = 20.
    SPO = 5.
    SI = 30.
    SALK = 7.
    SNN = 0.
    # 各层悬浮固体初值
    TSS_1 = 10.
    TSS_2 = 20.
    TSS_3 = 40.
    TSS_4 = 70.
    TSS_5 = 200.
    TSS_6 = 300.
    TSS_7 = 350.
    TSS_8 = 350.
    TSS_9 = 2000.
    TSS_10 = 4000.
    TSS_11 = 4000.
    TSS_12 = 4000.
    TSS_13 = 4000.
    TSS_14 = 4000.
    TSS_15 = 4000.
    TSS_16 = 4000.
    TSS_17 = 4000.
    TSS_18 = 4000.
    TSS_19 = 4000.
    TSS_20 = 4000.


class PhysicalDefaultValue:
    """物理学默认值"""
    AREA = 100.  # 表面积
    DEPTH = 3.  # 深度
    TOTAL_LAYER = 10  # 总分层数
    FEED_LAYER = 7  # 进料层，默认是第7层


class PumpOperationMode(Enum):
    """回流模式选择"""
    BY_RATIO = 1
    BY_FLOW = 2


class OperationDefaultValue:
    """运行参数默认值"""
    RAS_RATIO = 0.2  # 回流比
    WAS_RATIO = 0.02  # 排泥比
    Q_RAS = 100.  # 回流量
    Q_WAS = 2.  # 排泥流量


class TakacsDefaultValue:
    """Takacs沉降动力学参数默认值"""
    V_BDN = 274.
    V_MAX = 410.
    RH = 0.0004
    RP = 0.0025
    FNS = 0.001
    X_MIN_MAX = 20.
    XT = 3000.


class PhysicalTypeName:
    """物理学类别"""
    AREA = "area"  # 表面积
    DEPTH = "depth"  # 深度
    TOTAL_LAYER = "total_layer"  # 总分层数
    FEED_LAYER = "feed_layer"  # 进料层


class OperationTypeName:
    """运行参数类别"""
    RAS_MODE = "ras_mode"  # 回流模式
    WAS_MODE = "was_mode"  # 排泥模式
    RAS_RATIO = "ras_ratio"  # 回流比
    WAS_RATIO = "was_ratio"  # 排泥比
    Q_RAS = "q_ras"  # 回流量
    Q_WAS = "q_was"  # 排泥流量


class TakacsTypeName:
    """Takacs沉降动力学参数默认值"""
    V_BDN = "v_bdn"
    V_MAX = "v_max"
    RH = "rh"
    RP = "rp"
    FNS = "fns"
    X_MIN_MAX = "x_min_max"
    XT = "xt"
