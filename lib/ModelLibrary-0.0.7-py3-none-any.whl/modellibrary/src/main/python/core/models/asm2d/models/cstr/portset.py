# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import PortType
from modellibrary.src.main.python.core.common.port import Port


class PortSet:
    """模块端口集合"""

    def __init__(self, module):
        self.__module = module

        self.in_port = Port(module, f"{module.id}_{PortType.IN_PORT.value}", PortType.IN_PORT)
        self.out_port = Port(module, f"{module.id}_{PortType.OUT_PORT.value}", PortType.OUT_PORT)
        self.pump_port = Port(module, f"{module.id}_{PortType.PUMP_PORT.value}", PortType.PUMP_PORT)
        self.converge_port = Port(module, f"{module.id}_{PortType.CONVERGE_PORT.value}", PortType.CONVERGE_PORT)

        self.in_port.add_vars(self.__module.variables.get_port_in_vars())
        self.out_port.add_vars(self.__module.variables.get_port_out_vars())
        self.pump_port.add_vars(self.__module.variables.get_port_pump_vars())
        self.converge_port.add_vars(self.__module.variables.get_port_converge_vars())

        self.set = {
            self.in_port.id: self.in_port,
            self.out_port.id: self.out_port,
            self.pump_port.id: self.pump_port,
            self.converge_port.id: self.converge_port,
        }

    @property
    def module(self):
        return self.__module
